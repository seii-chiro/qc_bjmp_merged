import "leaflet/dist/leaflet.css";

const addressMap = () => {
    return (
        <div>addressMap</div>
    )
}

export default addressMap